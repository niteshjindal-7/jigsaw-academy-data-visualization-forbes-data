# Data-Visualization---Forbes-Data-
Used the data from the HTML page “The World's Most Valuable Brands List - Forbes.html”, to read the data pertaining to “Most Valuable Brands” to create a visualization for 4 sectors: (a) Technology (b) Luxury (c) Automotive (d) Financial Services
